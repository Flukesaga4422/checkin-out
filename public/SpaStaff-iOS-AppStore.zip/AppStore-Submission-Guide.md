# คู่มือการนำแอพขึ้น Apple App Store และ TestFlight

## สิ่งที่ต้องเตรียม
1. บัญชี **Apple Developer Account** (สมัครที่ https://developer.apple.com ค่าบริการ $99/ปี)
2. เครื่อง **Mac** พร้อมโปรแกรม **Xcode** (ดาวน์โหลดฟรีจาก Mac App Store)

---

## ขั้นตอนที่ 1: ติดตั้ง Capacitor iOS ในโปรเจกต์
รันคำสั่งเหล่านี้ใน Terminal ของโปรเจกต์:
```bash
npm install @capacitor/core @capacitor/cli @capacitor/ios
npx cap init "ระบบพนักงานร้านสปา" "com.spastaff.app"
npm run build
npx cap add ios
```

---

## ขั้นตอนที่ 2: เปิดโปรเจกต์ใน Xcode
```bash
npx cap open ios
```
1. ใน Xcode คลิกที่โปรเจกต์ **App** ด้านซ้าย
2. ไปที่แท็บ **Signing & Capabilities**
3. เลือก **Team** เป็นบัญชี Apple Developer ของคุณ
4. Bundle Identifier จะเป็น `com.spastaff.app`

---

## ขั้นตอนที่ 3: ตั้งค่าไอคอนและข้อความขออนุญาต
ไฟล์ `Info.plist` และ `PrivacyInfo.xcprivacy` ในโฟลเดอร์นี้ได้รับการตั้งค่าขอสิทธิ์กล้อง (Camera) และคลังรูปภาพ (Photo Library) เป็นภาษาไทยไว้เรียบร้อยแล้ว:
- `NSCameraUsageDescription`: "แอปต้องการเข้าถึงกล้องเพื่อถ่ายภาพยืนยันตัวตนตอนเช็คอินเข้างานของพนักงาน"
- `NSPhotoLibraryUsageDescription`: "แอปต้องการเข้าถึงรูปภาพเพื่อแนบเอกสารหรือรูปถ่ายใบรับรองแพทย์สำหรับการลาป่วย"

---

## ขั้นตอนที่ 4: ทดสอบผ่าน TestFlight และส่งตรวจ App Store
1. ในแถบเมนู Xcode ด้านบน เลือกปลายทางเป็น **Any iOS Device (arm64)**
2. เมนู **Product** ➔ **Archive**
3. เมื่อคอมไพล์เสร็จ หน้าต่าง Organizer จะเปิดขึ้นมา ให้กด **Distribute App**
4. เลือก **App Store Connect** ➔ กด **Upload**
5. เข้าเว็บ **App Store Connect** (https://appstoreconnect.apple.com)
6. ไปที่เมนู **TestFlight** เพื่อส่งให้พนักงานในร้านทดสอบผ่านแอป TestFlight ได้ทันที
7. เมื่อพร้อม ให้กด **Submit for Review** เพื่อให้ทีมงาน Apple ตรวจสอบและเปิดให้ดาวน์โหลดบน App Store ทั่วโลก!
